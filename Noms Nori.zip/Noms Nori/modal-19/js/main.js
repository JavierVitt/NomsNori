$(function() {

	// $('#exampleModalCenter').modal();

	
})